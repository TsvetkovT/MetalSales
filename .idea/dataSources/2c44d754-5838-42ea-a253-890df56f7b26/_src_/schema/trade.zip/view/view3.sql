CREATE VIEW `view3` AS
  SELECT
    `trade`.`enquiry`.`Ime`                                                            AS `Ime`,
    `trade`.`enquiry`.`Kompania`                                                       AS `Kompania`,
    `trade`.`enquiry`.`Telefon`                                                        AS `Telefon`,
    `trade`.`enquiry`.`Email`                                                          AS `Email`,
    `trade`.`enquiry`.`Adres`                                                          AS `Adres`,
    `trade`.`enquiry`.`Tiptransport`                                                   AS `Tiptransport`,
    `trade`.`enquiry`.`Datad`                                                          AS `Datad`,
    `trade`.`enquiry`.`Vypros`                                                         AS `Vypros`,
    if((`trade`.`enquiry`.`Zapitvane` LIKE '%<%'), '0', `trade`.`enquiry`.`Zapitvane`) AS `Zapitvane`,
    `trade`.`wp_zupload`.`id`                                                          AS `id`,
    `trade`.`wp_zupload`.`name`                                                        AS `name`,
    `trade`.`wp_zupload`.`content`                                                     AS `content`,
    `trade`.`wp_zupload`.`type`                                                        AS `type`,
    `trade`.`wp_zupload`.`size`                                                        AS `size`
  FROM (`trade`.`enquiry`
    LEFT JOIN `trade`.`wp_zupload` ON ((`trade`.`enquiry`.`Zapitvane` = `trade`.`wp_zupload`.`name`)))