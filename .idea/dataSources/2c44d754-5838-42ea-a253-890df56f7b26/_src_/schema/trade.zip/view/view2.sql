CREATE VIEW `view2` AS
  SELECT
    `trade`.`enquiry`.`Ime`          AS `Ime`,
    `trade`.`enquiry`.`Kompania`     AS `Kompania`,
    `trade`.`enquiry`.`Telefon`      AS `Telefon`,
    `trade`.`enquiry`.`Email`        AS `Email`,
    `trade`.`enquiry`.`Adres`        AS `Adres`,
    `trade`.`enquiry`.`Tiptransport` AS `Tiptransport`,
    `trade`.`enquiry`.`Datad`        AS `Datad`,
    `trade`.`enquiry`.`Vypros`       AS `Vypros`,
    `trade`.`enquiry`.`Zapitvane`    AS `Zapitvane`
  FROM `trade`.`enquiry`
  WHERE (`trade`.`enquiry`.`Zapitvane` LIKE '%<%')