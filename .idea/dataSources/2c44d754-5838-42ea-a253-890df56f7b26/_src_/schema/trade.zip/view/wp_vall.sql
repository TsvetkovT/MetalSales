CREATE VIEW `wp_vall` AS
  SELECT
    `trade`.`wp_sklad`.`SkladBg` AS `Склад`,
    `trade`.`wp_grupa`.`GrupaBG` AS `Група`,
    `trade`.`wp_nal`.`Product`   AS `Продукт`,
    `trade`.`wp_nal`.`Tip`       AS `Тип`,
    `trade`.`wp_nal`.`Razmer`    AS `Размер`
  FROM ((`trade`.`wp_nal`
    LEFT JOIN `trade`.`wp_sklad` ON ((`trade`.`wp_nal`.`Sklad` = `trade`.`wp_sklad`.`SkladRu`))) LEFT JOIN
    `trade`.`wp_grupa` ON ((`trade`.`wp_nal`.`Grupa` = `trade`.`wp_grupa`.`GrupaRu`)))
  WHERE (`trade`.`wp_nal`.`Razmer` <> 0)