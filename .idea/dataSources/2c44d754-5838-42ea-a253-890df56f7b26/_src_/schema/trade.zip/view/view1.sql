CREATE VIEW `view1` AS
  SELECT
    `trade`.`view3`.`Ime`          AS `Ime`,
    `trade`.`view3`.`Kompania`     AS `Kompania`,
    `trade`.`view3`.`Telefon`      AS `Telefon`,
    `trade`.`view3`.`Email`        AS `Email`,
    `trade`.`view3`.`Adres`        AS `Adres`,
    `trade`.`view3`.`Tiptransport` AS `Tiptransport`,
    `trade`.`view3`.`Datad`        AS `Datad`,
    `trade`.`view3`.`Vypros`       AS `Vypros`,
    `trade`.`view3`.`Zapitvane`    AS `Zapitvane`,
    `trade`.`view3`.`id`           AS `id`,
    `trade`.`view3`.`name`         AS `name`,
    `trade`.`view3`.`content`      AS `content`,
    `trade`.`view3`.`type`         AS `type`,
    `trade`.`view3`.`size`         AS `size`
  FROM `trade`.`view3`
  WHERE (`trade`.`view3`.`Zapitvane` <> '0')